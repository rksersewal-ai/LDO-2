export const MOCK_DOCUMENTS = [
  {
    id: "DOC-2026-9021",
    name: "HVAC Sub-Assembly Wiring Diagram",
    type: "PDF",
    size: "4.2 MB",
    revision: "C.1",
    status: "Approved",
    author: "J. Halloway",
    owner: "Engineering Dept",
    date: "2026-03-20",
    linkedPL: "PL-55092",
    ocrStatus: "Completed",
    ocrConfidence: 98,
    category: "Electrical Schema",
    lifecycle: "Active",
    pages: 12,
    tags: ["Engineering", "Electrical", "Schematic"]
  },
  {
    id: "DOC-2026-9022",
    name: "Thermal Tolerance Specification v2",
    type: "DOCX",
    size: "1.8 MB",
    revision: "A.4",
    status: "In Review",
    author: "M. Chen",
    owner: "Compliance Team",
    date: "2026-03-21",
    linkedPL: "PL-55092",
    ocrStatus: "Processing",
    ocrConfidence: null,
    category: "Specification",
    lifecycle: "Draft",
    pages: 45,
    tags: ["Compliance", "Thermal"]
  },
  {
    id: "DOC-2026-9023",
    name: "Turbine Blade CAD Render (Section B)",
    type: "PNG",
    size: "12.5 MB",
    revision: "B.0",
    status: "Draft",
    author: "A. Kowalski",
    owner: "Design Ops",
    date: "2026-03-22",
    linkedPL: "PL-88104",
    ocrStatus: "Failed",
    ocrConfidence: 12,
    category: "CAD Output",
    lifecycle: "Draft",
    pages: 1,
    tags: ["Mechanical", "CAD", "WIP"]
  },
  {
    id: "DOC-2025-1104",
    name: "Legacy Actuator Calibrations",
    type: "PDF",
    size: "8.1 MB",
    revision: "F.2",
    status: "Obsolete",
    author: "S. Vance",
    owner: "Quality Assurance",
    date: "2025-11-14",
    linkedPL: "PL-11002",
    ocrStatus: "Completed",
    ocrConfidence: 85,
    category: "Calibration Log",
    lifecycle: "Archived",
    pages: 8,
    tags: ["Archive", "Calibration"]
  },
  {
    id: "DOC-2026-9040",
    name: "Q1 Material Yield Report",
    type: "XLSX",
    size: "3.4 MB",
    revision: "A.1",
    status: "Approved",
    author: "System_Auto",
    owner: "Operations",
    date: "2026-03-23",
    linkedPL: "N/A",
    ocrStatus: "Not Required",
    ocrConfidence: null,
    category: "Financial / Yield",
    lifecycle: "Active",
    pages: 3,
    tags: ["Report", "Materials"]
  }
];

export const MOCK_PL_RECORDS = [
  {
    id: "PL-55092",
    title: "Turbine Housing Thermal Control Node",
    status: "Active",
    lifecycle: "Production",
    owner: "M. Chen",
    lastUpdated: "2026-03-21",
    description: "Core PL record managing the thermal and electrical specifications for the main turbine housing unit.",
    linkedDocs: ["DOC-2026-9021", "DOC-2026-9022"],
    linkedBOMs: ["SUB-1100", "PART-1102"],
    cases: ["CAS-992"],
    ledgerEntries: 14
  },
  {
    id: "PL-88104",
    title: "Advanced Propulsion Sub-System",
    status: "In Development",
    lifecycle: "Prototyping",
    owner: "A. Kowalski",
    lastUpdated: "2026-03-22",
    description: "Next-gen propulsion mechanics including new aerodynamic CAD outputs.",
    linkedDocs: ["DOC-2026-9023"],
    linkedBOMs: ["ASSY-1000"],
    cases: [],
    ledgerEntries: 5
  },
  {
    id: "PL-11002",
    title: "Legacy Actuator MK-I",
    status: "Obsolete",
    lifecycle: "End of Life",
    owner: "S. Vance",
    lastUpdated: "2025-11-14",
    description: "Depreciated actuator calibration and specification records.",
    linkedDocs: ["DOC-2025-1104"],
    linkedBOMs: ["PART-9901 (Legacy)"],
    cases: ["CAS-104", "CAS-209"],
    ledgerEntries: 89
  }
];

export const MOCK_BOM_TREE = [
  {
    id: "ASSY-1000",
    name: "Main Propulsion Unit",
    type: "Assembly",
    expanded: true,
    children: [
      {
        id: "SUB-1100",
        name: "Turbine Housing",
        type: "Sub-Assembly",
        expanded: true,
        children: [
          { id: "PART-1101", name: "Outer Casing (Titanium)", type: "Component" },
          { id: "PART-1102", name: "Thermal Shielding", type: "Component" }
        ]
      },
      {
        id: "SUB-1200",
        name: "Control Electronics",
        type: "Sub-Assembly",
        expanded: false,
        children: [
          { id: "PART-1201", name: "Main Logic Board", type: "Component" },
          { id: "PART-1202", name: "Sensor Array", type: "Component" }
        ]
      }
    ]
  }
];

export const MOCK_AUDIT_LOG = [
  { id: "EVT-9921", action: "READ", user: "m.chen", document: "DOC-2026-9021", ip: "10.0.4.22", time: "10:42:01 AM" },
  { id: "EVT-9922", action: "UPDATE", user: "j.halloway", document: "DOC-2026-9022", ip: "10.0.4.15", time: "11:05:12 AM" },
  { id: "EVT-9923", action: "OCR_SUCCESS", user: "SYSTEM", document: "DOC-2026-9021", ip: "localhost", time: "11:06:00 AM" },
  { id: "EVT-9924", action: "APPROVAL_REQ", user: "a.kowalski", document: "DOC-2026-9023", ip: "10.0.8.50", time: "11:15:33 AM" },
  { id: "EVT-9925", action: "DOWNLOAD", user: "s.vance", document: "DOC-2025-1104", ip: "10.0.2.11", time: "11:40:02 AM" },
];