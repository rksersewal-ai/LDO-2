// Extended mock data for all modules

export const MOCK_SEARCH_RESULTS = [
  { type: 'Document', id: 'DOC-2026-9021', title: 'HVAC Sub-Assembly Wiring Diagram', status: 'Approved', snippet: 'Contains thermal shielding specs referenced in PL-55092', matchSource: 'OCR Text' },
  { type: 'PL', id: 'PL-55092', title: 'Turbine Housing Thermal Control Node', status: 'Active', snippet: 'Core PL record for turbine housing unit', matchSource: 'Record Title' },
  { type: 'Work', id: 'WRK-4401', title: 'Thermal Shield Inspection Cycle Q1', status: 'Complete', snippet: 'Linked to DOC-2026-9021 and PL-55092', matchSource: 'Reference' },
  { type: 'Case', id: 'CAS-992', title: 'Drawing Discrepancy — Turbine Housing', status: 'Open', snippet: 'Flagged mismatch in Rev C.1 vs CAD output', matchSource: 'Case Notes' },
  { type: 'Document', id: 'DOC-2026-9022', title: 'Thermal Tolerance Specification v2', status: 'In Review', snippet: 'References 1200°C tolerance limits', matchSource: 'OCR Extraction' },
];

export const MOCK_WORK_LEDGER = [
  { id: 'WRK-4401', title: 'Thermal Shield Inspection Cycle Q1', type: 'Inspection', status: 'Complete', assignee: 'J. Halloway', linkedPL: 'PL-55092', linkedDoc: 'DOC-2026-9021', date: '2026-03-18', priority: 'Normal' },
  { id: 'WRK-4402', title: 'Actuator Calibration Re-Verification', type: 'Calibration', status: 'In Progress', assignee: 'S. Vance', linkedPL: 'PL-11002', linkedDoc: 'DOC-2025-1104', date: '2026-03-20', priority: 'High' },
  { id: 'WRK-4403', title: 'Propulsion CAD Output Review', type: 'Review', status: 'Pending', assignee: 'A. Kowalski', linkedPL: 'PL-88104', linkedDoc: 'DOC-2026-9023', date: '2026-03-22', priority: 'Normal' },
  { id: 'WRK-4404', title: 'Material Yield Quarterly Reconciliation', type: 'Reporting', status: 'Complete', assignee: 'System_Auto', linkedPL: 'N/A', linkedDoc: 'DOC-2026-9040', date: '2026-03-23', priority: 'Low' },
  { id: 'WRK-4405', title: 'Wiring Diagram Compliance Audit', type: 'Audit', status: 'Pending Verification', assignee: 'M. Chen', linkedPL: 'PL-55092', linkedDoc: 'DOC-2026-9021', date: '2026-03-21', priority: 'High' },
];

export const MOCK_CASES = [
  { id: 'CAS-992', title: 'Drawing Discrepancy — Turbine Housing', status: 'Open', severity: 'High', assignee: 'M. Chen', linkedPL: 'PL-55092', linkedDocs: ['DOC-2026-9021', 'DOC-2026-9022'], created: '2026-03-15', updated: '2026-03-22', description: 'Rev C.1 of wiring diagram has dimensional mismatch with the latest CAD render. Requires engineering review.' },
  { id: 'CAS-104', title: 'Legacy Actuator End-of-Life Disposition', status: 'Closed', severity: 'Medium', assignee: 'S. Vance', linkedPL: 'PL-11002', linkedDocs: ['DOC-2025-1104'], created: '2025-10-01', updated: '2026-01-15', description: 'Formal EOL disposition and archival workflow for MK-I actuator documentation.' },
  { id: 'CAS-209', title: 'Calibration Data Integrity Review', status: 'In Progress', severity: 'Medium', assignee: 'J. Halloway', linkedPL: 'PL-11002', linkedDocs: [], created: '2026-02-10', updated: '2026-03-20', description: 'Investigating data anomalies in legacy calibration records flagged by OCR analysis.' },
  { id: 'CAS-1001', title: 'Propulsion Spec Missing Approval Chain', status: 'Open', severity: 'Low', assignee: 'A. Kowalski', linkedPL: 'PL-88104', linkedDocs: ['DOC-2026-9023'], created: '2026-03-22', updated: '2026-03-23', description: 'CAD output uploaded without completing the standard approval workflow.' },
];

export const MOCK_APPROVALS = [
  { id: 'APR-301', title: 'Thermal Tolerance Spec v2 — Final Approval', type: 'Document Approval', status: 'Pending', requester: 'M. Chen', linkedDoc: 'DOC-2026-9022', linkedPL: 'PL-55092', dueDate: '2026-03-25', submitted: '2026-03-21', urgency: 'High' },
  { id: 'APR-302', title: 'Propulsion CAD Render Release', type: 'Document Approval', status: 'Pending', requester: 'A. Kowalski', linkedDoc: 'DOC-2026-9023', linkedPL: 'PL-88104', dueDate: '2026-03-28', submitted: '2026-03-22', urgency: 'Normal' },
  { id: 'APR-303', title: 'Work Record WRK-4405 Verification Sign-off', type: 'Work Verification', status: 'Pending', requester: 'M. Chen', linkedDoc: 'DOC-2026-9021', linkedPL: 'PL-55092', dueDate: '2026-03-24', submitted: '2026-03-21', urgency: 'High' },
  { id: 'APR-290', title: 'Q4 Material Report Final Release', type: 'Report Approval', status: 'Approved', requester: 'System_Auto', linkedDoc: 'DOC-2026-9040', linkedPL: 'N/A', dueDate: '2026-03-15', submitted: '2026-03-10', urgency: 'Low' },
  { id: 'APR-285', title: 'Legacy Actuator Archive Authorization', type: 'Disposition', status: 'Rejected', requester: 'S. Vance', linkedDoc: 'DOC-2025-1104', linkedPL: 'PL-11002', dueDate: '2026-02-28', submitted: '2026-02-20', urgency: 'Normal' },
];

export const MOCK_OCR_JOBS = [
  { id: 'OCR-8801', document: 'DOC-2026-9021', filename: 'hvac_wiring_diagram.pdf', status: 'Completed', confidence: 98, pages: 12, startTime: '2026-03-20 09:14', endTime: '2026-03-20 09:16', extractedRefs: 4 },
  { id: 'OCR-8802', document: 'DOC-2026-9022', filename: 'thermal_spec_v2.docx', status: 'Processing', confidence: null, pages: 45, startTime: '2026-03-23 10:30', endTime: null, extractedRefs: 0 },
  { id: 'OCR-8803', document: 'DOC-2026-9023', filename: 'turbine_cad_render.png', status: 'Failed', confidence: 12, pages: 1, startTime: '2026-03-22 14:01', endTime: '2026-03-22 14:02', extractedRefs: 0, failureReason: 'Image resolution below minimum threshold (150 DPI required). Detected: 72 DPI.' },
  { id: 'OCR-8804', document: 'DOC-2025-1104', filename: 'actuator_calibrations.pdf', status: 'Completed', confidence: 85, pages: 8, startTime: '2025-11-14 11:00', endTime: '2025-11-14 11:03', extractedRefs: 2 },
  { id: 'OCR-8805', document: 'DOC-2026-9040', filename: 'q1_yield_report.xlsx', status: 'Skipped', confidence: null, pages: 3, startTime: null, endTime: null, extractedRefs: 0 },
];

export const MOCK_AUDIT_EXTENDED = [
  { id: 'EVT-9921', action: 'READ', module: 'Documents', user: 'm.chen', entity: 'DOC-2026-9021', ip: '10.0.4.22', time: '2026-03-23 10:42:01', severity: 'Info' },
  { id: 'EVT-9922', action: 'UPDATE', module: 'Documents', user: 'j.halloway', entity: 'DOC-2026-9022', ip: '10.0.4.15', time: '2026-03-23 11:05:12', severity: 'Info' },
  { id: 'EVT-9923', action: 'OCR_SUCCESS', module: 'OCR', user: 'SYSTEM', entity: 'DOC-2026-9021', ip: 'localhost', time: '2026-03-23 11:06:00', severity: 'Info' },
  { id: 'EVT-9924', action: 'APPROVAL_REQ', module: 'Approvals', user: 'a.kowalski', entity: 'DOC-2026-9023', ip: '10.0.8.50', time: '2026-03-23 11:15:33', severity: 'Warning' },
  { id: 'EVT-9925', action: 'DOWNLOAD', module: 'Documents', user: 's.vance', entity: 'DOC-2025-1104', ip: '10.0.2.11', time: '2026-03-23 11:40:02', severity: 'Info' },
  { id: 'EVT-9926', action: 'LOGIN_FAIL', module: 'Auth', user: 'unknown', entity: 'N/A', ip: '10.0.9.88', time: '2026-03-23 11:42:10', severity: 'Critical' },
  { id: 'EVT-9927', action: 'PERMISSION_DENIED', module: 'Admin', user: 's.vance', entity: 'Settings', ip: '10.0.2.11', time: '2026-03-23 11:45:00', severity: 'Warning' },
  { id: 'EVT-9928', action: 'CREATE', module: 'Work Ledger', user: 'm.chen', entity: 'WRK-4405', ip: '10.0.4.22', time: '2026-03-23 12:00:15', severity: 'Info' },
  { id: 'EVT-9929', action: 'OCR_FAIL', module: 'OCR', user: 'SYSTEM', entity: 'DOC-2026-9023', ip: 'localhost', time: '2026-03-23 14:02:00', severity: 'Critical' },
  { id: 'EVT-9930', action: 'DELETE', module: 'Banners', user: 'admin', entity: 'BNR-003', ip: '10.0.1.1', time: '2026-03-23 14:30:00', severity: 'Warning' },
];

export const MOCK_NOTIFICATIONS = [
  { id: 'NTF-001', type: 'approval', title: 'Approval Required', message: 'Thermal Tolerance Spec v2 awaiting your sign-off', entity: 'APR-301', time: '10 min ago', read: false },
  { id: 'NTF-002', type: 'ocr', title: 'OCR Completed', message: 'Extraction finished for DOC-2026-9021 (98% confidence)', entity: 'DOC-2026-9021', time: '28 min ago', read: false },
  { id: 'NTF-003', type: 'case', title: 'Case Updated', message: 'CAS-992 received new comment from M. Chen', entity: 'CAS-992', time: '1 hour ago', read: false },
  { id: 'NTF-004', type: 'system', title: 'Maintenance Scheduled', message: 'OCR Engine restart at 03:00 AM UTC tonight', entity: null, time: '2 hours ago', read: true },
  { id: 'NTF-005', type: 'ocr', title: 'OCR Failed', message: 'Extraction failed for DOC-2026-9023 — low resolution', entity: 'DOC-2026-9023', time: '3 hours ago', read: true },
  { id: 'NTF-006', type: 'work', title: 'Work Record Assigned', message: 'WRK-4403 Propulsion CAD Output Review assigned to you', entity: 'WRK-4403', time: '5 hours ago', read: true },
];

export const MOCK_BANNERS = [
  { id: 'BNR-001', title: 'System Maintenance', message: 'OCR Engine Restart scheduled for 03:00 AM UTC. Expect minor delays in processing.', link: null, active: true, validFrom: '2026-03-23', validTo: '2026-03-24', order: 1 },
  { id: 'BNR-002', title: 'Q1 Compliance Deadline', message: 'All Q1 compliance documents must be submitted by March 31, 2026.', link: '/documents', active: true, validFrom: '2026-03-15', validTo: '2026-03-31', order: 2 },
  { id: 'BNR-003', title: 'New BOM Module Available', message: 'The BOM Explorer has been upgraded with version comparison capabilities.', link: '/bom', active: false, validFrom: '2026-03-10', validTo: '2026-03-20', order: 3 },
];

export const MOCK_REPORTS = [
  { id: 'RPT-001', name: 'Document Status Summary', category: 'Documents', generated: '2026-03-23', status: 'Ready', description: 'Overview of all document statuses across active PL records.' },
  { id: 'RPT-002', name: 'OCR Processing Report', category: 'OCR', generated: '2026-03-23', status: 'Ready', description: 'Weekly OCR pipeline performance and extraction accuracy metrics.' },
  { id: 'RPT-003', name: 'Approval Cycle Time Analysis', category: 'Approvals', generated: '2026-03-22', status: 'Ready', description: 'Average approval turnaround by document type and department.' },
  { id: 'RPT-004', name: 'Work Ledger Activity Report', category: 'Work Ledger', generated: '2026-03-23', status: 'Generating', description: 'Monthly summary of work record completions and open items.' },
  { id: 'RPT-005', name: 'User Access Audit Report', category: 'Admin', generated: '2026-03-20', status: 'Ready', description: 'Login frequency, session durations, and access pattern analysis.' },
];
